package com.example.inventoryapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class AddItemActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_item)

        val nameInput = findViewById<EditText>(R.id.editName)
        val qtyInput = findViewById<EditText>(R.id.editQty)
        val saveBtn = findViewById<Button>(R.id.btnSave)

        val dao = AppDatabase.getInstance(this).inventoryDao()

        saveBtn.setOnClickListener {
            val name = nameInput.text.toString().trim()
            val qty = qtyInput.text.toString().trim().toIntOrNull() ?: 0

            if (name.isBlank()) {
                Toast.makeText(this, "Name required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                dao.insertItem(InventoryItem(name = name, quantity = qty))
                finish()
            }
        }
    }
}
