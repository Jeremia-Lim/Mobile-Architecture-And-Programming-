package com.example.inventoryapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class NotificationsActivity : AppCompatActivity() {

    private val SMS_PERMISSION_CODE = 101

    private lateinit var textPermissionStatus: TextView
    private lateinit var btnRequestPermission: Button
    private lateinit var switchLowInventory: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notifications)

        textPermissionStatus = findViewById(R.id.textPermissionStatus)
        btnRequestPermission = findViewById(R.id.btnRequestPermission)
        switchLowInventory = findViewById(R.id.switchLowInventory)

        updatePermissionStatus()

        // Button: request permission
        btnRequestPermission.setOnClickListener {
            if (hasSmsPermission()) {
                Toast.makeText(this, "SMS permission already granted.", Toast.LENGTH_SHORT).show()
                updatePermissionStatus()
            } else {
                requestSmsPermission()
            }
        }


        switchLowInventory.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                // Only send alert if permission granted
                if (hasSmsPermission()) {

                    sendLowInventorySmsAlert()
                } else {
                    Toast.makeText(
                        this,
                        "SMS permission not granted. Notifications disabled, app still works.",
                        Toast.LENGTH_LONG
                    ).show()
                    // Turn it back off since feature cannot run
                    switchLowInventory.isChecked = false
                }
            }
        }
    }

    private fun hasSmsPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestSmsPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.SEND_SMS),
            SMS_PERMISSION_CODE
        )
    }

    private fun updatePermissionStatus() {
        if (hasSmsPermission()) {
            textPermissionStatus.text = "SMS Permission Granted"
        } else {
            textPermissionStatus.text = "SMS Permission Not Granted"
        }
    }


    private fun sendLowInventorySmsAlert() {
        val testPhoneNumber = "5551234567" // Placeholder
        val message = "Inventory Alert: An item is low in stock."

        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(testPhoneNumber, null, message, null, null)
            Toast.makeText(this, "Low inventory SMS alert sent.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "SMS attempt failed (expected without SIM). Permission logic works.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission granted.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(
                    this,
                    "Permission denied. App will continue without SMS notifications.",
                    Toast.LENGTH_LONG
                ).show()
                // Ensure switch stays off if permission denied
                switchLowInventory.isChecked = false
            }
            updatePermissionStatus()
        }
    }
}
