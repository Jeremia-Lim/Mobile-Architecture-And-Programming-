package com.example.inventoryapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch

class InventoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventory)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerInventory)
        val addButton = findViewById<Button>(R.id.btnAddItem)

        val dao = AppDatabase.getInstance(this).inventoryDao()

        val adapter = InventoryAdapter(emptyList()) { item ->
            lifecycleScope.launch { dao.deleteItem(item) }
        }

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        lifecycleScope.launch {
            dao.getAllItems().collect { items ->
                adapter.update(items)
            }
        }

        addButton.setOnClickListener {
            startActivity(Intent(this, AddItemActivity::class.java))
        }
    }
}
